package com.example.collection.recyclerview;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.collection.R;

public class PostViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

    public ImageView ivImg, ivLike, ivShare;
    public TextView tvLikeCount, tvUserName, tvPostText;
    private PostAdapter mAdapter;

    public PostViewHolder(@NonNull View itemView, PostAdapter postAdapter) {
        super(itemView);
        mAdapter = postAdapter;
        ivImg = (ImageView) itemView.findViewById(R.id.iv_Img);
        ivLike = (ImageView) itemView.findViewById(R.id.iv_Like);
        ivShare = (ImageView) itemView.findViewById(R.id.iv_Share);
        tvLikeCount = (TextView) itemView.findViewById(R.id.tv_LikeCount);
        tvUserName = (TextView) itemView.findViewById(R.id.tv_UserName);
        tvPostText = (TextView) itemView.findViewById(R.id.tv_PostText);

        ivLike.setOnClickListener(this);
        ivShare.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        int position = getAdapterPosition();

        switch (view.getId()) {
            case R.id.iv_Like:
                mAdapter.onLikeClicked(position);
                break;
            case R.id.iv_Share:
                break;
        }
    }
}
