package com.example.collection;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.collection.model.PostItem;
import com.example.collection.recyclerview.PostAdapter;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<PostItem> listItem = new ArrayList<>();
        /*LinearLayout llScrollParent = (LinearLayout) findViewById(R.id.ll_scroll);*/
        RecyclerView rvList = findViewById(R.id.rv_list);

        for (int i = 0; i < 5; i++) {
            PostItem item = new PostItem(true, 125, "text","https://get.wallhere.com/photo/bridge-USA-Golden-Gate-Bridge-sky-1516651.jpg","wow");


            listItem.add(i,item);
        }

        PostAdapter adapter = new PostAdapter(this, listItem);
        rvList.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        rvList.setAdapter(adapter);


        /*for(PostItem item : listItem) {

            View v = View.inflate(this, R.layout.post_item, null);
            TextView tvUserName = v.findViewById(R.id.tv_UserName);
            TextView tvPostText = v.findViewById(R.id.tv_PostText);

            tvUserName.setText(item.getUserName());
            tvPostText.setText(item.getPostText());

            llScrollParent.addView(v);

        }*/

    }
}