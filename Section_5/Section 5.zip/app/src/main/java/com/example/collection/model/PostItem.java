package com.example.collection.model;

public class PostItem {

    String postimgUrl;
    String userName;
    String postText;
    int postLikeCount;
    boolean isUserLike;

    public PostItem(boolean isUserLike, int postLikeCount, String userName, String postimgUrl, String postText) {
        this.postimgUrl = postimgUrl;
        this.userName = userName;
        this.postText = postText;
        this.postLikeCount = postLikeCount;
        this.isUserLike = isUserLike;
    }


    public String getPostimgUrl() {
        return postimgUrl;
    }

    public String getUserName() {
        return userName;
    }

    public String getPostText() {
        return postText;
    }

    public int getPostLikeCount() {
        return postLikeCount;
    }

    public boolean isUserLike() {
        return isUserLike;
    }
}
