package com.example.layout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnTouchListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.iv_like).setOnClickListener(this);
        findViewById(R.id.iv_share).setOnClickListener(this);

        findViewById(R.id.photo).setOnTouchListener(this);
        findViewById(R.id.photo).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.iv_like:
                Toast.makeText(MainActivity.this, "I love this!", Toast.LENGTH_SHORT).show();
                break;

            case R.id.iv_share:
                Toast.makeText(MainActivity.this, "Sharing this!", Toast.LENGTH_SHORT).show();
                break;

            case R.id.photo:
                Toast.makeText(MainActivity.this, "Touch Photo!", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {

        switch (motionEvent.getAction()) {

            case MotionEvent.ACTION_DOWN:
                Toast.makeText(MainActivity.this, "Touch Down!", Toast.LENGTH_SHORT).show();
                break;
            case MotionEvent.ACTION_UP:
                Toast.makeText(MainActivity.this, "Touch Up!", Toast.LENGTH_SHORT).show();
                break;
        }

        return false;
    }
}