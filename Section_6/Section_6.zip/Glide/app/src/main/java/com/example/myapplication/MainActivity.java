package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class MainActivity extends AppCompatActivity {
    ImageView ivimage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivimage = (ImageView) findViewById(R.id.iv_Image);

        findViewById(R.id.btn_start).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startLoadingImage();
            }
        });
    }

    private void startLoadingImage() {
        String url = "http://news.samsungdisplay.com/wp-content/uploads/2018/08/2.png";
        Glide.with(this).load(url).into(ivimage);

    }
}